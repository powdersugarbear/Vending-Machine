// Vending Machine for Game Systems Development 1, by Anne Botwinik - 12/11/2022 -

#include <iostream>

using namespace std;

char input = 0;
int bills = 0;
float total = 0;
char selection;
char more;
bool valid = true;
bool addmorefood = true;
bool addmore = true;
bool addmoredrinks = true;

int main()
{
    cout << "========================================" << endl;
    cout << "====== Welcome to the Dining Hall ======" << endl;
    cout << "========================================" << endl;
    cout << "Please Choose Your Dining Voucher:" << endl;
    while(addmore == true){

        cout << "(1)$10, (2)$20, (3)$50, (4)$100 : ";

        cin >> input;
        switch(input)
        {
            case '1':
                bills = 10;
                valid = true;
                break;
            case '2':
                bills = 20;
                valid = true;
                break;
            case '3':
                bills = 50;
                valid = true;
                break;
            case '4':
                bills = 100;
                valid = true;
                break;
            default:
                cout << "Invalid Selection. Please enter 1-4" << endl;
                valid = false;
                break;
        }
        if(valid == true){
            total = total + bills;
            cout << "You've inserted: $" << bills << endl;
            cout << "Funds available: $" << total << endl;
        }

        bool invalidmore = true;
        while(invalidmore == true){
            cout << "Add more funds (Y/N)? ";
            cin >> more;
            if(more=='Y'||more=='y'){
                cout<<"Please insert your coins/bills"<<endl;
                addmore = true;
                invalidmore = false;
            }
            else if(more=='N'||more=='n'){
                addmore = false;
                invalidmore = false;
                if(total<=0){
                    cout<<"You did not purchase a voucher. Goodbye."<<endl;
                    addmorefood = false;
                    return 0;
                }
                else{
                    addmorefood = true;
                }
            }
            else{
                cout << "Your answer is invalid. Please answer Y or N:" << endl;
                invalidmore = true;
            }
        }
    }
    cout<<"STOP THE BILL LOOP AND START THE FOOD LOOP"<<endl;
    while(addmorefood == true){
            cout<<"Please make a selection:"<<endl;
            cout<<"(P)otato Chips $2.50, (H)am Burger $5.50, (C)hicken & Rice $5.50, (B)rooklyn Pizza $4.50"<<endl;
            cin >> selection;
            if(selection=='P'||selection=='p'){
                    if(total<2.50){
                        cout<<"Insufficient funds to purchase selection"<<endl;
                        cout<<"Please select a different item."<<endl;
                    }
                    else{
                        total = total - 2.50;
                    }
            }
            else if(selection=='H'||selection=='h'){
                    if(total<5.50){
                        cout<<"Insufficient funds to purchase selection"<<endl;
                        cout<<"Please select a different item."<<endl;
                    }
                    else{
                        total = total - 5.50;
                    }
            }
            else if(selection=='C'||selection=='c'){
                    if(total<5.50){
                        cout<<"Insufficient funds to purchase selection"<<endl;
                        cout<<"Please select a different item."<<endl;
                    }
                    else{
                        total = total - 5.50;
                    }
            }
            else if(selection=='B'||selection=='b'){
                    if(total<4.50){
                        cout<<"Insufficient funds to purchase selection"<<endl;
                        cout<<"Please select a different item."<<endl;
                    }
                    else{
                        total = total - 4.50;
                    }
            }
            else{
                    cout << "Invalid selection" << endl;
            }

            cout << "Funds available: $" << total << endl;

            if(total==0){
                addmorefood = false;
                cout<<"Enjoy your Meal!"<<endl;
                return 0;
            }
            else if(total<=2){
                addmorefood = false;
            }
            else if(total<1.50){
                addmorefood = false;
                cout<<"Your change is $"<<total<<endl;
                cout<<"Enjoy your Meal!"<<endl;
            }
            else{
                bool invalidmore = true;
                while(invalidmore == true){
                    cout << "Add more meals (Y/N)? ";
                    cin >> more;
                    if(more=='Y'||more=='y'){
                            addmorefood = true;
                            invalidmore = false;
                    }
                    else if(more=='N'||more=='n'){
                            addmorefood = false;
                            invalidmore = false;
                    }
                    else{
                            cout << "Your answer is invalid. Please answer Y or N:" << endl;
                            invalidmore = true;
                    }
                }
            }
    }
    cout<<"STOP THE FOOD LOOP AND START THE BEVERAGE LOOP"<<endl;
    while(addmoredrinks == true){
            cout << "Please make a selection:" << endl;
            cout << "(A)quaVeena $1.50, (B)epsi $2.00, (C)ool Cola $2.00, (G)atorade $2.25" << endl;
            cin >> selection;
            if(selection=='A'||selection=='a'){
                    total = total - 1.50;
            }
            else if(selection=='B'||selection=='b'){
                    if(total<2.00){
                        cout<<"Insufficient funds to purchase selection"<<endl;
                        cout<<"Please select another beverage."<<endl;
                    }
                    else{
                        total = total - 2.00;
                    }

            }
            else if(selection=='C'||selection=='c'){
                    if(total<2.00){
                        cout<<"Insufficient funds to purchase selection"<<endl;
                        cout<<"Please select another beverage."<<endl;
                    }
                    else{
                        total = total - 2.00;
                    }
            }
            else if(selection=='G'||selection=='g'){
                    if(total<2.25){
                        cout<<"Insufficient funds to purchase selection"<<endl;
                        cout<<"Please select another beverage."<<endl;
                    }
                    else{
                        total = total - 2.25;
                    }
            }
            else{
                    cout << "Invalid selection" << endl;
            }

            cout << "Funds available: $" << total << endl;
            if(total==0){
                addmoredrinks = false;
                cout<<"Enjoy your Meal!"<<endl;
            }
            else if(total<1.50){
                addmoredrinks = false;
                cout<<"Your change is $"<<total<<endl;
                cout<<"Enjoy your Meal!"<<endl;
            }
            else{
                bool invalidmore = true;
                while(invalidmore == true){
                    cout << "Add more drinks (Y/N): ";
                    cin >> more;
                    if(more=='Y'||more=='y'){
                            addmoredrinks = true;
                            invalidmore = false;
                    }
                    else if(more=='N'||more=='n'){
                            addmoredrinks = false;
                            invalidmore = false;
                            cout<<"Your change is $"<<total<<endl;
                            cout<<"Enjoy your Meal!"<<endl;
                    }
                    else{
                            cout << "Your answer is invalid. Please answer Y or N" << endl;
                            invalidmore = true;
                    }
                }
            }
    }


    return 0;
}
